<?php include('include/header.php');?>
<!-- partial -->
<div class="container-fluid page-body-wrapper">
<!-- partial:../../partials/_sidebar.html -->
<?php include('include/side_bar.php'); ?>
<!-- partial -->
<div class="main-panel">
<div class="content-wrapper">
   <div class="page-header">
      <h3 class="page-title">Add Property Details </h3>
      <nav aria-label="breadcrumb">
         <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Add Property Details</li>
         </ol>
      </nav>
   </div>
              <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-body">
                 <!--  <h4 class="card-title">Main Image</h4> -->
                  <form class="form-sample">
                    <!-- <p class="card-description"> Property info </p> -->
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Name</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" />
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Phone No</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Location</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control"/>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Email</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Kitchen</label>
                          <div class="col-sm-9">
                            <select class="form-control">
                              <option hidden="0">Please Select Kitchen*</option>
                              <option>1</option>
                              <option>2</option>
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">BHK</label>
                          <div class="col-sm-9">
                            <select class="form-control">
                              <option hidden="0">Please Select Bhk*</option>
                              <option>1 Bhk</option>
                              <option>2 Bhk</option>
                              <option>3 Bhk</option>
                            </select>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Property Type</label>
                          <div class="col-sm-9">
                            <select class="form-control">
                              <option hidden="0">Please Select Type*</option>
                              <option>Appartment</option>
                              <option>Villa</option>
                              <option>Builder Flooor</option>
                              <option>Indeependent House</option>
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Parking</label>
                          <div class="col-sm-4">
                            <div class="form-check">
                              <label class="form-check-label">
                                <input type="radio" class="form-check-input" name="membershipRadios"
                                  id="membershipRadios1" value="" checked> Yes </label>
                            </div>
                          </div>
                          <div class="col-sm-5">
                            <div class="form-check">
                              <label class="form-check-label">
                                <input type="radio" class="form-check-input" name="membershipRadios"
                                  id="membershipRadios2" value="option2"> No </label>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <!-- <p class="card-description"> Address </p> -->
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="form-label col-sm-3" for="customFile">Upload File</label>
                          <div class="col-sm-9">
                            <input type="file" class="form-control" id="customFile" />
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">State</label>
                          <div class="col-sm-9">
                            <select class="form-control">
                              <option hidden="0">Please Select State*</option>
                              <option>Maharashtra</option>
                              <option>Delhi</option>
                              <option>Uttar Pradesh</option>
                              <option>Kerala</option>
                            </select>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Room</label>
                          <div class="col-sm-9">
                            <select class="form-control">
                              <option hidden="none">Please Select Room*</option>
                              <option>1</option>
                              <option>2</option>
                              <option>3</option>
                              <option>4</option>
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Bathroom</label>
                          <div class="col-sm-9">
                            <select class="form-control">
                              <option>1</option>
                              <option>2</option>
                            </select>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Bedrooms</label>
                          <div class="col-sm-9">
                            <select class="form-control">
                              <option hidden="0">Please Select Bedrooms*</option>
                              <option>1</option>
                              <option>2</option>
                              <option>3</option>
                              <option>4</option>
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Garages</label>
                          <div class="col-sm-9">
                            <select class="form-control">
                              <option hidden="0">Please Select Garages*</option>
                              <option>1</option>
                              <option>2</option>
                            </select>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Livingroom</label>
                          <div class="col-sm-9">
                            <select class="form-control">
                              <option hidden="0">Please Select Livingroom*</option>
                              <option>1</option>
                              <option>2</option>
                              <option>3</option>
                              <option>4</option>
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Area</label>
                          <div class="col-sm-9">
                            <select class="form-control">
                              <option hidden="0">Please Select Area*</option>
                              <option>12850</option>
                              <option>12860</option>
                              <option>12880</option>
                              <option>13860</option>
                            </select>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Orientent</label>
                          <div class="col-sm-9">
                            <select class="form-control">
                              <option hidden="0">Please Select Orientent*</option>
                              <option value="1">East</option>
                              <option value="1">West</option>
                              <option value="1">North</option>
                              <option value="1">South</option>
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Year Built</label>
                           <div class="col-sm-9">
                            <input type="date" placeholder="dd/mm/yyyy" class="form-control air-datepicker"
                            data-position='bottom right'>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Description</label>
                            <div class="col-sm-8">
                        <!-- <textarea class="form-control" id="exampleTextarea1" rows="4"></textarea> -->
                        <textarea id="editor" class="form-control" rows="4"></textarea>
                            </div>
                          </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group row">
                           <button type="submit" class="btn btn-gradient-primary mr-2">Submit</button>
                      <button class="btn btn-light">Cancel</button>
                          </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
</div>
<!-- content-wrapper ends -->
<!-- partial:../../partials/_footer.html -->
<?php include('include/footer.php'); ?>