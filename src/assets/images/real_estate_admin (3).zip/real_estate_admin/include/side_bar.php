        
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
            <li class="nav-item nav-profile">
              <a href="#" class="nav-link">
                <div class="nav-profile-image">
                  <img src="assets/images/faces/client-icon.jpg" alt="profile">
                  <span class="login-status online"></span>
                  <!--change to offline or busy as needed-->
                </div>
                <div class="nav-profile-text d-flex flex-column">
                  <span class="font-weight-bold mb-2">David Grey. H</span>
                  <span class="text-secondary text-small">Project Manager</span>
                </div>
                <i class="mdi mdi-bookmark-check text-success nav-profile-badge"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="index.php">
                <span class="menu-title">Dashboard</span>
                <i class="mdi mdi-home menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" data-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
                <span class="menu-title">Banner</span>
                <i class="menu-arrow"></i>
                <i class="mdi mdi-tooltip-image menu-icon"></i>
              </a>
              <div class="collapse" id="ui-basic">
                <ul class="nav flex-column sub-menu">
                  <li class="nav-item"> <a class="nav-link" href="add_banner.php">Add Banner</a></li>
                  <li class="nav-item"> <a class="nav-link" href="manage_banner.php">Manage Banner</a></li>
                </ul>
              </div>
            </li>

            
            <li class="nav-item">
              <a class="nav-link" data-toggle="collapse" href="#property" aria-expanded="false" aria-controls="property">
                <span class="menu-title">Property Details</span>
                <i class="menu-arrow"></i>
                <i class="mdi mdi-houzz menu-icon"></i>
              </a>
              <div class="collapse" id="property">
                <ul class="nav flex-column sub-menu">
                  <li class="nav-item"> <a class="nav-link" href="add_property.php"> Add Property Details </a></li>
                  <li class="nav-item"> <a class="nav-link" href="manage-property.php"> Manage Properties </a></li>
                </ul>
              </div>
            </li>
            <li class="nav-item">
              <a class="nav-link" data-toggle="collapse" href="#general-pages" aria-expanded="false" aria-controls="general-pages">
                <span class="menu-title">Associaed</span>
                <i class="menu-arrow"></i>
                <i class="mdi mdi-medical-bag menu-icon"></i>
              </a>
              <div class="collapse" id="general-pages">
                <ul class="nav flex-column sub-menu">
                  <li class="nav-item"> <a class="nav-link" href="add_about.php"> Add Associaed</a></li>
                  <li class="nav-item"> <a class="nav-link" href="manage_about.php"> Manage Associaed</a></li>
                  
                </ul>
              </div>
            </li>
            <li class="nav-item">
              <a class="nav-link" data-toggle="collapse" href="#associated" aria-expanded="false" aria-controls="associated">
                <span class="menu-title">About</span>
                <i class="menu-arrow"></i>
                <i class="mdi mdi-human-male-female menu-icon"></i>
              </a>
              <div class="collapse" id="associated">
                <ul class="nav flex-column sub-menu">
                  <li class="nav-item"> <a class="nav-link" href="add_associa.php"> Add About</a></li>
                  <li class="nav-item"> <a class="nav-link" href="manage_associ.php"> Manage About </a></li>
                  
                </ul>
              </div>
            </li>
            <li class="nav-item">
              <a class="nav-link" data-toggle="collapse" href="#contact" aria-expanded="false" aria-controls="contact">
                <span class="menu-title">Contact</span>
                <i class="menu-arrow"></i>
                <i class="mdi mdi-phone-classic menu-icon"></i>
              </a>
              <div class="collapse" id="contact">
                <ul class="nav flex-column sub-menu">
                  <li class="nav-item"> <a class="nav-link" href="contact.php"> Add Contact </a></li>
                  <li class="nav-item"> <a class="nav-link" href="contact_manage.php"> Manage Contact </a></li>
                </ul>
              </div>
            </li>
            <li class="nav-item">
              <a class="nav-link" data-toggle="collapse" href="#Categories" aria-expanded="false" aria-controls="Categories">
                <span class="menu-title">Categories</span>
                <i class="menu-arrow"></i>
                <i class="mdi mdi-script menu-icon"></i>
              </a>
              <div class="collapse" id="Categories">
                <ul class="nav flex-column sub-menu">
                  <li class="nav-item"> <a class="nav-link" href="categorie.php"> Add Categories </a></li>
                  <li class="nav-item"> <a class="nav-link" href="categorie_manage.php"> Manage Categories </a></li>
                </ul>
              </div>
            </li>
            <li class="nav-item">
              <a class="nav-link" data-toggle="collapse" href="#testimonial" aria-expanded="false" aria-controls="testimonial">
                <span class="menu-title">Testimonials</span>
                <i class="menu-arrow"></i>
                <i class="mdi mdi-walk menu-icon"></i>
              </a>
              <div class="collapse" id="testimonial">
                <ul class="nav flex-column sub-menu">
                  <li class="nav-item"> <a class="nav-link" href="testimonial.php"> Add Testimonials </a></li>
                  <li class="nav-item"> <a class="nav-link" href="testimonial_manage.php"> Manage Categories </a></li>
                </ul>
              </div>
            </li>
            <li class="nav-item">
              <a class="nav-link" data-toggle="collapse" href="#enquiry" aria-expanded="false" aria-controls="enquiry">
                <span class="menu-title">Enquiry</span>
                <i class="menu-arrow"></i>
                <i class="mdi mdi-account-search menu-icon"></i>
              </a>
              <div class="collapse" id="enquiry">
                <ul class="nav flex-column sub-menu">
                  <li class="nav-item"> <a class="nav-link" href="enquiry.php"> Manage Enquiry</a></li>
                </ul>
              </div>
            </li>
            <li class="nav-item">
              <a class="nav-link" data-toggle="collapse" href="#review" aria-expanded="false" aria-controls="review">
                <span class="menu-title">Review</span>
                <i class="menu-arrow"></i>
                <i class="mdi mdi-account-star menu-icon"></i>
              </a>
              <div class="collapse" id="review">
                <ul class="nav flex-column sub-menu">
                  <li class="nav-item"> <a class="nav-link" href="review.php"> Add Review</a></li>
                  <li class="nav-item"> <a class="nav-link" href="manage_review.php"> Manage Review </a></li>
                </ul>
              </div>
            </li>
            <li class="nav-item">
              <a class="nav-link" data-toggle="collapse" href="#location" aria-expanded="false" aria-controls="location">
                <span class="menu-title">Location</span>
                <i class="menu-arrow"></i>
                <i class="mdi mdi-walk menu-icon"></i>
              </a>
              <div class="collapse" id="location">
                <ul class="nav flex-column sub-menu">
                  <li class="nav-item"> <a class="nav-link" href="location.php"> Add Location</a></li>
                  <li class="nav-item"> <a class="nav-link" href="manage_location.php"> Manage Location</a></li>
                </ul>
              </div>
            </li>
            <li class="nav-item">
              <a class="nav-link" data-toggle="collapse" href="#sociallink" aria-expanded="false" aria-controls="sociallink">
                <span class="menu-title">Social Link</span>
                <i class="menu-arrow"></i>
                <i class="mdi mdi-facebook-box menu-icon"></i>
              </a>
              <div class="collapse" id="sociallink">
                <ul class="nav flex-column sub-menu">
                  <li class="nav-item"> <a class="nav-link" href="social_link.php"> Add Social Link</a></li>
                  <li class="nav-item"> <a class="nav-link" href="manage_social_link.php"> Manage Social Link</a></li>
                </ul>
              </div>
            </li>
          </ul>
        </nav>