<?php include('include/header.php');?>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:../../partials/_sidebar.html -->
<?php include('include/side_bar.php'); ?>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title"> Manage Banner</h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="index-2.html">Home</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Manage Banner</li>
                </ol>
              </nav>
            </div>
            <div class="row">
                <div class="col-lg-12 grid-margin stretch-card">
                    <div class="card">
                      <div class="card-body">
                        <table class="table table-striped table-bordered">
                           <thead>
                             <tr>
                           <th scope="col">Photo</th>
                           <th scope="col">Actions</th>
                           </tr>
                           </thead>
                          <tbody>
                        <tr>
                            <td class="text-center"> 
                              <img src="assets/images/icon-form.jpg" alt="logo" />
                            </td>
                           <td>
                            <button type="button" class="btn btn-success"><i class="fas fa-edit"></i></button>
                            <button type="button" class="btn btn-danger"><i class="far fa-trash-alt"></i></button>
                         </td>
                        </tr>
                        <tr>
                            <td class="text-center"> 
                              <img src="assets/images/icon-form.jpg" alt="logo" />
                            </td>
                           <td>
                            <button type="button" class="btn btn-success"><i class="fas fa-edit"></i></button>
                            <button type="button" class="btn btn-danger"><i class="far fa-trash-alt"></i></button>
                         </td>
                        </tr>
                        <tr>
                            <td class="text-center"> 
                              <img src="assets/images/icon-form.jpg" alt="logo" />
                            </td>
                           <td>
                            <button type="button" class="btn btn-success"><i class="fas fa-edit"></i></button>
                            <button type="button" class="btn btn-danger"><i class="far fa-trash-alt"></i></button>
                         </td>
                        </tr>
                       </tbody>
                       </table>
                      </div>
                    </div>
                  </div> 
            </div>
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:../../partials/_footer.html -->
<?php include('include/footer.php'); ?>         