<?php include('include/header.php');?>
      <div class="container-fluid page-body-wrapper">
        <!-- partial:../../partials/_sidebar.html -->
<?php include('include/side_bar.php'); ?>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title"> Manage Property </h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="index-2.html">Home</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Manage property</li>
                </ol>
              </nav>
            </div>
            <div class="row">
                <div class="col-lg-12 grid-margin stretch-card">
                    <div class="card">
                      <div class="card-body">
                        <table class="table table-striped table-bordered">
                          <div class="row">
                          <thead>
                            <tr>
                              <th>Name</th>
                              <th>Phone No</th>
                              <th>Email</th>
                              <th>Location</th>
                              <th>Kitchen</th>
                              <th>BHK</th>
                              <th>Property Type</th>
                              <th> Parking </th>
                              <th>Room</th>
                              <th>Bathroom</th>
                              <th>Bedrooms</th>
                              <th>Garages</th>
                              <th>Description</th>
                              <th>Acction</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td> Herman Beck </td>
                              <td>+915267823</td>
                              <td>
                                kazifahim93@gmail.com
                              </td>
                              <td>kalkaji</td>
                              <td>1</td>
                              <td>1Bhk</td>
                              <td>villa</td>
                              <td>yes</td>
                              <td>1</td>
                              <td>1</td>
                              <td>1</td>
                              <td>1</td>
                              <td>ABC</td>
                              <td>
                            <button type="button" class="btn btn-success"><i class="fas fa-edit"></i></button>
                            <button type="button" class="btn btn-danger"><i class="far fa-trash-alt"></i></button>
                              </td>
                            </tr>
                            <tr>
                              <td> Herman Beck </td>
                              <td>+915267823</td>
                              <td>
                                kazifahim93@gmail.com
                              </td>
                              <td>kalkaji</td>
                              <td>2</td>
                              <td>2Bhk</td>
                              <td>Appartment</td>
                              <td>no</td>
                              <td>2</td>
                              <td>2</td>
                              <td>2</td>
                              <td>2</td>
                              <td>ABC</td>
                              <td>
                            <button type="button" class="btn btn-success"><i class="fas fa-edit"></i></button>
                            <button type="button" class="btn btn-danger"><i class="far fa-trash-alt"></i></button>
                             </td>
                            </tr>
                            <tr>
                              <td> Herman Beck </td>
                              <td>+915267823</td>
                              <td>
                                kazifahim93@gmail.com
                              </td>
                              <td>kalkaji</td>
                              <td>3</td>
                              <td>3Bhk</td>
                              <td>Builder Floor</td>
                              <td>yes</td>
                              <td>3</td>
                              <td>3</td>
                              <td>3</td>
                              <td>3</td>
                              <td>ABC</td>
                              <td>
                            <button type="button" class="btn btn-success"><i class="fas fa-edit"></i></button>
                            <button type="button" class="btn btn-danger"><i class="far fa-trash-alt"></i></button>
                              </td>
                            </tr>
                            <!-- <tr>
                              <td> 4 </td>
                              <td> Peter Meggik </td>
                              <td>
                                <div class="progress">
                                  <div class="progress-bar bg-primary" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                              </td>
                              <td> inside </td>
                              <td> kalkaji </td>
                            </tr> -->
                          </tbody>
                          </div>
                        </table>
                      </div>
                    </div>
                  </div> 
            </div>
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:../../partials/_footer.html -->
<?php include('include/footer.php'); ?>       