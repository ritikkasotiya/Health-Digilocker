<?php include('include/header.php');?>
<!-- partial -->
<div class="container-fluid page-body-wrapper">
<!-- partial:../../partials/_sidebar.html -->
<?php include('include/side_bar.php'); ?>
<!-- partial -->
<div class="main-panel">
<div class="content-wrapper">
   <div class="page-header">
      <h3 class="page-title"> Testimonials </h3>
      <nav aria-label="breadcrumb">
         <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Add Testimonials</li>
         </ol>
      </nav>
   </div>
   <div class="row">
      <div class="col-12 grid-margin stretch-card">
         <div class="card">
            <div class="card-body">
               <!-- <h4 class="card-title">Add Testimonials</h4>
               <p class="card-description">Add class <code>Testimonials</code></p> -->
               <form class="forms-sample">
                  <div class="row">
                     <div class="col-xl-6 col-lg-6 col-12">
                        <div class="form-group">
                          <label class="form-label col-sm-3" for="customFile">Upload File</label>
                            <input type="file" class="form-control" id="customFile" />
                        </div>
                     </div>
                     <div class="col-xl-6 col-lg-6 col-12">
                        <div class="form-group">
                           <label for="exampleInputName1">Person Name</label>
                           <input type="text" class="form-control" id="exampleInputName1" placeholder="Name">
                        </div>
                     </div>
                     <div class="col-xl-8 col-lg-6 col-12">
                        <div class="form-group">
                           <label for="exampleTextarea1">Description</label>
                           <textarea id="editor" class="form-control" rows="4"></textarea>
                        </div>
                     </div>
                     <div class="col-12 form-group mg-t-8">
                        <button type="submit" class="btn btn-gradient-primary mr-2">Submit</button>
                        <button class="btn btn-light">Cancel</button>
                     </div>
                  </div>
               </form>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- content-wrapper ends -->
<!-- partial:../../partials/_footer.html -->
<?php include('include/footer.php'); ?>