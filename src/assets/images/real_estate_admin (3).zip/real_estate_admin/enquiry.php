<?php include('include/header.php');?>
      <div class="container-fluid page-body-wrapper">
        <!-- partial:../../partials/_sidebar.html -->
<?php include('include/side_bar.php'); ?>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title"> Manage Enquiry </h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="index-2.html">Home</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Manage Enquiry</li>
                </ol>
              </nav>
            </div>
            <div class="row">
                <div class="col-lg-12 grid-margin stretch-card">
                    <div class="card">
                      <div class="card-body">
                        <table class="table table-striped table-bordered">
                          <div class="row">
                          <thead>
                            <tr>
                              <th>Name</th>
                              <th>Phone No</th>
                              <th>Email</th>
                              <th>Message</th>
                              <th>Acction</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td> Herman Beck </td>
                              <td>+915267823</td>
                              <td>
                                kazifahim93@gmail.com
                              </td>
                              <td>ABC</td>
                              <td>
                            <button type="button" class="btn btn-success"><i class="fas fa-edit"></i></button>
                            <button type="button" class="btn btn-danger"><i class="far fa-trash-alt"></i></button>
                              </td>
                            </tr>
                            <tr>
                              <td> Herman Beck </td>
                              <td>+915267823</td>
                              <td>
                                kazifahim93@gmail.com
                              </td>
                              <td>ABC</td>
                              <td>
                            <button type="button" class="btn btn-success"><i class="fas fa-edit"></i></button>
                            <button type="button" class="btn btn-danger"><i class="far fa-trash-alt"></i></button>
                             </td>
                            </tr>
                            <tr>
                              <td> Herman Beck </td>
                              <td>+915267823</td>
                              <td>
                                kazifahim93@gmail.com
                              </td>
                              <td>ABC</td>
                              <td>
                            <button type="button" class="btn btn-success"><i class="fas fa-edit"></i></button>
                            <button type="button" class="btn btn-danger"><i class="far fa-trash-alt"></i></button>
                              </td>
                            </tr>
                            <!-- <tr>
                              <td> 4 </td>
                              <td> Peter Meggik </td>
                              <td>
                                <div class="progress">
                                  <div class="progress-bar bg-primary" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                              </td>
                              <td> inside </td>
                              <td> kalkaji </td>
                            </tr> -->
                          </tbody>
                          </div>
                        </table>
                      </div>
                    </div>
                  </div> 
            </div>
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:../../partials/_footer.html -->
<?php include('include/footer.php'); ?>       